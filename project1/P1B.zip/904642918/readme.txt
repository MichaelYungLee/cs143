NAME: Michael Lee
EMAIL: michael.y.lee.cs@gmail.com
UID: 904642918

Using 1 late day for Project 1
